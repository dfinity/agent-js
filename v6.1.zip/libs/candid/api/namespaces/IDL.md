---
title: IDL
editUrl: false
next: true
prev: true
---

## Classes

### BoolClass

Defined in: [packages/core/src/candid/idl.ts:522](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L522)

Represents an IDL Bool

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`boolean`\>

#### Constructors

##### Constructor

> **new BoolClass**(): [`BoolClass`](#boolclass)

###### Returns

[`BoolClass`](#boolclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:562](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L562)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:523](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L523)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:531](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L531)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is boolean`

Defined in: [packages/core/src/candid/idl.ts:535](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L535)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is boolean`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `boolean`

Defined in: [packages/core/src/candid/idl.ts:550](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L550)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`boolean`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:546](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L546)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:542](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L542)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`boolean`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`boolean`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is BoolClass`

Defined in: [packages/core/src/candid/idl.ts:527](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L527)

###### Parameters

###### instance

`any`

###### Returns

`instance is BoolClass`

***

### CandidDecodeError

Defined in: [packages/core/src/candid/idl.ts:106](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L106)

Error thrown when candid decoding fails due to a type mismatch
between the expected and received types.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new CandidDecodeError**(`message`): [`CandidDecodeError`](#candiddecodeerror)

Defined in: [packages/core/src/candid/idl.ts:109](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L109)

###### Parameters

###### message

`string`

###### Returns

[`CandidDecodeError`](#candiddecodeerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string` = `'CandidDecodeError'`

Defined in: [packages/core/src/candid/idl.ts:107](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L107)

###### Overrides

`Error.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### `abstract` ConstructType

Defined in: [packages/core/src/candid/idl.ts:380](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L380)

Represents an IDL type.

#### Extends

- [`Type`](#abstract-type)\<`T`\>

#### Extended by

- [`VecClass`](#vecclass)
- [`OptClass`](#optclass)
- [`RecordClass`](#recordclass)
- [`VariantClass`](#variantclass)
- [`RecClass`](#recclass)
- [`FuncClass`](#funcclass)
- [`ServiceClass`](#serviceclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new ConstructType**\<`T`\>(): [`ConstructType`](#abstract-constructtype)\<`T`\>

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:322](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L322)

###### Inherited from

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:321](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L321)

###### Inherited from

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:364](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L364)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:323](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L323)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Inherited from

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:345](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L345)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Inherited from

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:362](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L362)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Inherited from

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:352](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L352)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

***

### EmptyClass

Defined in: [packages/core/src/candid/idl.ts:403](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L403)

Represents an IDL Empty, a type which has no inhabitants.
Since no values exist for this type, it cannot be serialised or deserialised.
Result types like `Result<Text, Empty>` should always succeed.

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`never`\>

#### Constructors

##### Constructor

> **new EmptyClass**(): [`EmptyClass`](#emptyclass)

###### Returns

[`EmptyClass`](#emptyclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:436](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L436)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:404](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L404)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:412](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L412)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is never`

Defined in: [packages/core/src/candid/idl.ts:416](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L416)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:432](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L432)

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:428](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L428)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:420](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L420)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(): `never`

Defined in: [packages/core/src/candid/idl.ts:424](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L424)

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is EmptyClass`

Defined in: [packages/core/src/candid/idl.ts:408](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L408)

###### Parameters

###### instance

`any`

###### Returns

`instance is EmptyClass`

***

### FixedIntClass

Defined in: [packages/core/src/candid/idl.ts:859](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L859)

Represents an IDL fixed-width Int(n)

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint` \| `number`\>

#### Constructors

##### Constructor

> **new FixedIntClass**(`_bits`): [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:868](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L868)

###### Parameters

###### \_bits

`number`

###### Returns

[`FixedIntClass`](#fixedintclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:868](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L868)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:910](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L910)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:860](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L860)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:872](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L872)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:876](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L876)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number` \| `bigint`

Defined in: [packages/core/src/candid/idl.ts:901](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L901)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number` \| `bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:896](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L896)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:892](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L892)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:914](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L914)

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FixedIntClass`

Defined in: [packages/core/src/candid/idl.ts:864](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L864)

###### Parameters

###### instance

`any`

###### Returns

`instance is FixedIntClass`

***

### FixedNatClass

Defined in: [packages/core/src/candid/idl.ts:922](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L922)

Represents an IDL fixed-width Nat(n)

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint` \| `number`\>

#### Constructors

##### Constructor

> **new FixedNatClass**(`_bits`): [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:931](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L931)

###### Parameters

###### \_bits

`number`

###### Returns

[`FixedNatClass`](#fixednatclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:931](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L931)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:972](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L972)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:923](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L923)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:935](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L935)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:939](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L939)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number` \| `bigint`

Defined in: [packages/core/src/candid/idl.ts:963](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L963)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number` \| `bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:958](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L958)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:954](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L954)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:976](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L976)

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FixedNatClass`

Defined in: [packages/core/src/candid/idl.ts:927](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L927)

###### Parameters

###### instance

`any`

###### Returns

`instance is FixedNatClass`

***

### FloatClass

Defined in: [packages/core/src/candid/idl.ts:795](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L795)

Represents an IDL Float

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`number`\>

#### Constructors

##### Constructor

> **new FloatClass**(`_bits`): [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:804](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L804)

###### Parameters

###### \_bits

`number`

###### Returns

[`FloatClass`](#floatclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:804](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L804)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:847](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L847)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:796](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L796)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:810](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L810)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is number`

Defined in: [packages/core/src/candid/idl.ts:814](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L814)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is number`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number`

Defined in: [packages/core/src/candid/idl.ts:837](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L837)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:832](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L832)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/candid/idl.ts:821](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L821)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number`

###### Returns

`Uint8Array`\<`ArrayBuffer`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:851](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L851)

###### Parameters

###### x

`number`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FloatClass`

Defined in: [packages/core/src/candid/idl.ts:800](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L800)

###### Parameters

###### instance

`any`

###### Returns

`instance is FloatClass`

***

### FuncClass

Defined in: [packages/core/src/candid/idl.ts:1883](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1883)

Represents an IDL function reference.

#### Param

Argument types.

#### Param

Return types.

#### Param

Function annotations.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

#### Type Parameters

##### Args

`Args` *extends* [`GenericIdlFuncArgs`](#genericidlfuncargs) = [`GenericIdlFuncArgs`](#genericidlfuncargs)

##### Rets

`Rets` *extends* [`GenericIdlFuncRets`](#genericidlfuncrets) = [`GenericIdlFuncRets`](#genericidlfuncrets)

#### Constructors

##### Constructor

> **new FuncClass**\<`Args`, `Rets`\>(`argTypes`, `retTypes`, `annotations?`): [`FuncClass`](#funcclass)\<`Args`, `Rets`\>

Defined in: [packages/core/src/candid/idl.ts:1902](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1902)

###### Parameters

###### argTypes

`Args`

###### retTypes

`Rets`

###### annotations?

`string`[] = `[]`

###### Returns

[`FuncClass`](#funcclass)\<`Args`, `Rets`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### annotations

> **annotations**: `string`[] = `[]`

Defined in: [packages/core/src/candid/idl.ts:1905](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1905)

##### argTypes

> **argTypes**: `Args`

Defined in: [packages/core/src/candid/idl.ts:1903](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1903)

##### retTypes

> **retTypes**: `Rets`

Defined in: [packages/core/src/candid/idl.ts:1904](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1904)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1972](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1972)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1887](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1887)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1936](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1936)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1910](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1910)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is [Principal, string]`

Defined in: [packages/core/src/candid/idl.ts:1913](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1913)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is [Principal, string]`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): \[[`Principal`](../../../principal/api.md#principal), `string`\]

Defined in: [packages/core/src/candid/idl.ts:1951](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1951)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1983](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1983)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`__namedParameters`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1926](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1926)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### \_\_namedParameters

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`__namedParameters`): `string`

Defined in: [packages/core/src/candid/idl.ts:1979](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1979)

###### Parameters

###### \_\_namedParameters

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

Defined in: [packages/core/src/candid/idl.ts:1891](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1891)

###### Parameters

###### instance

`any`

###### Returns

`instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

##### argsToString()

> `static` **argsToString**(`types`, `v`): `string`

Defined in: [packages/core/src/candid/idl.ts:1895](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1895)

###### Parameters

###### types

[`Type`](#abstract-type)\<`any`\>[]

###### v

`any`[]

###### Returns

`string`

***

### IntClass

Defined in: [packages/core/src/candid/idl.ts:701](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L701)

Represents an IDL Int

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint`\>

#### Constructors

##### Constructor

> **new IntClass**(): [`IntClass`](#intclass)

###### Returns

[`IntClass`](#intclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:736](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L736)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:702](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L702)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:710](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L710)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:714](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L714)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `bigint`

Defined in: [packages/core/src/candid/idl.ts:731](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L731)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:727](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L727)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:723](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L723)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:740](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L740)

###### Parameters

###### x

`bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is IntClass`

Defined in: [packages/core/src/candid/idl.ts:706](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L706)

###### Parameters

###### instance

`any`

###### Returns

`instance is IntClass`

***

### NatClass

Defined in: [packages/core/src/candid/idl.ts:748](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L748)

Represents an IDL Nat

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint`\>

#### Constructors

##### Constructor

> **new NatClass**(): [`NatClass`](#natclass)

###### Returns

[`NatClass`](#natclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:783](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L783)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:749](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L749)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:757](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L757)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:761](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L761)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `bigint`

Defined in: [packages/core/src/candid/idl.ts:778](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L778)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:774](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L774)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:770](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L770)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:787](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L787)

###### Parameters

###### x

`bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is NatClass`

Defined in: [packages/core/src/candid/idl.ts:753](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L753)

###### Parameters

###### instance

`any`

###### Returns

`instance is NatClass`

***

### NullClass

Defined in: [packages/core/src/candid/idl.ts:570](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L570)

Represents an IDL Null

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`null`\>

#### Constructors

##### Constructor

> **new NullClass**(): [`NullClass`](#nullclass)

###### Returns

[`NullClass`](#nullclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:603](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L603)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:571](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L571)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:579](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L579)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is null`

Defined in: [packages/core/src/candid/idl.ts:583](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L583)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`_b`, `t`): `null`

Defined in: [packages/core/src/candid/idl.ts:598](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L598)

###### Parameters

###### \_b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:594](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L594)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:590](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L590)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`null`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is NullClass`

Defined in: [packages/core/src/candid/idl.ts:575](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L575)

###### Parameters

###### instance

`any`

###### Returns

`instance is NullClass`

***

### OptClass

Defined in: [packages/core/src/candid/idl.ts:1200](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1200)

Represents an IDL Option

#### Param

#### Extends

- [`ConstructType`](#abstract-constructtype)\<\[`T`\] \| \[\]\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new OptClass**\<`T`\>(`_type`): [`OptClass`](#optclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1209](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1209)

###### Parameters

###### \_type

[`Type`](#abstract-type)\<`T`\>

###### Returns

[`OptClass`](#optclass)\<`T`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_type

> **\_type**: [`Type`](#abstract-type)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1209](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1209)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1321](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1321)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1201](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1201)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1238](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1238)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1213](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1213)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<\[\] \| \[`T`\]\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<\[\] \| \[`T`\]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): x is \[\] \| \[T\]

Defined in: [packages/core/src/candid/idl.ts:1217](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1217)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

x is \[\] \| \[T\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): \[\] \| \[`T`\]

Defined in: [packages/core/src/candid/idl.ts:1246](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1246)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

\[\] \| \[`T`\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1325](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1325)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1231](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1231)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

\[\] \| \[`T`\]

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1329](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1329)

###### Parameters

###### x

\[\] \| \[`T`\]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is OptClass<T>`

Defined in: [packages/core/src/candid/idl.ts:1205](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1205)

###### Type Parameters

###### T

`T`

###### Parameters

###### instance

`any`

###### Returns

`instance is OptClass<T>`

***

### `abstract` PrimitiveType

Defined in: [packages/core/src/candid/idl.ts:367](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L367)

Represents an IDL type.

#### Extends

- [`Type`](#abstract-type)\<`T`\>

#### Extended by

- [`EmptyClass`](#emptyclass)
- [`BoolClass`](#boolclass)
- [`NullClass`](#nullclass)
- [`ReservedClass`](#reservedclass)
- [`TextClass`](#textclass)
- [`IntClass`](#intclass)
- [`NatClass`](#natclass)
- [`FloatClass`](#floatclass)
- [`FixedIntClass`](#fixedintclass)
- [`FixedNatClass`](#fixednatclass)
- [`PrincipalClass`](#principalclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new PrimitiveType**\<`T`\>(): [`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### Returns

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:322](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L322)

###### Inherited from

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:321](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L321)

###### Inherited from

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:323](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L323)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Inherited from

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:345](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L345)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Inherited from

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:362](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L362)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Inherited from

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:358](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L358)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:352](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L352)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

***

### PrincipalClass

Defined in: [packages/core/src/candid/idl.ts:1825](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1825)

Represents an IDL principal reference

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<[`Principal`](../../../principal/api.md#principal)\>

#### Constructors

##### Constructor

> **new PrincipalClass**(): [`PrincipalClass`](#principalclass)

###### Returns

[`PrincipalClass`](#principalclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1859](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1859)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1826](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1826)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1834](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1834)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/core/src/candid/idl.ts:1838](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1838)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Principal`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/candid/idl.ts:1854](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1854)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

[`Principal`](../../../principal/api.md#principal)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1850](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1850)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1845](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1845)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1862](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1862)

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is PrincipalClass`

Defined in: [packages/core/src/candid/idl.ts:1830](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1830)

###### Parameters

###### instance

`any`

###### Returns

`instance is PrincipalClass`

***

### RecClass

Defined in: [packages/core/src/candid/idl.ts:1735](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1735)

Represents a reference to an IDL type, used for defining recursive data
types.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`T`\>

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new RecClass**\<`T`\>(): [`RecClass`](#recclass)\<`T`\>

###### Returns

[`RecClass`](#recclass)\<`T`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1793](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1793)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1736](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1736)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1777](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1777)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1748](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1748)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:1763](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1763)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:1786](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1786)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1797](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1797)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1770](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1770)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### fill()

> **fill**(`t`): `void`

Defined in: [packages/core/src/candid/idl.ts:1755](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1755)

###### Parameters

###### t

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Returns

`void`

##### getType()

> **getType**(): [`ConstructType`](#abstract-constructtype)\<`T`\> \| `undefined`

Defined in: [packages/core/src/candid/idl.ts:1759](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1759)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\> \| `undefined`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1804](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1804)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecClass<any>`

Defined in: [packages/core/src/candid/idl.ts:1744](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1744)

###### Parameters

###### instance

`any`

###### Returns

`instance is RecClass<any>`

***

### RecordClass

Defined in: [packages/core/src/candid/idl.ts:1341](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1341)

Represents an IDL Record

#### Param

mapping of function name to Type

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

#### Extended by

- [`TupleClass`](#tupleclass)

#### Constructors

##### Constructor

> **new RecordClass**(`fields?`): [`RecordClass`](#recordclass)

Defined in: [packages/core/src/candid/idl.ts:1355](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1355)

###### Parameters

###### fields?

`Record`\<`string`, [`Type`](#abstract-type)\> = `{}`

###### Returns

[`RecordClass`](#recordclass)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1353](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1353)

#### Accessors

##### fieldsAsObject

###### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1482](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1482)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1490](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1490)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1342](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1342)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1405](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1405)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1360](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1360)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Record<string, any>`

Defined in: [packages/core/src/candid/idl.ts:1376](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1376)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Record<string, any>`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `Record`\<`string`, `any`\>

Defined in: [packages/core/src/candid/idl.ts:1416](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1416)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`Record`\<`string`, `any`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1495](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1495)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1399](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1399)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### tryAsTuple()

> **tryAsTuple**(): [`Type`](#abstract-type)\<`any`\>[] \| `null`

Defined in: [packages/core/src/candid/idl.ts:1364](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1364)

###### Returns

[`Type`](#abstract-type)\<`any`\>[] \| `null`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1500](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1500)

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecordClass`

Defined in: [packages/core/src/candid/idl.ts:1346](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1346)

###### Parameters

###### instance

`any`

###### Returns

`instance is RecordClass`

***

### ReservedClass

Defined in: [packages/core/src/candid/idl.ts:611](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L611)

Represents an IDL Reserved

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`any`\>

#### Constructors

##### Constructor

> **new ReservedClass**(): [`ReservedClass`](#reservedclass)

###### Returns

[`ReservedClass`](#reservedclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:643](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L643)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:612](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L612)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:620](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L620)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`_x`): `_x is any`

Defined in: [packages/core/src/candid/idl.ts:624](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L624)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### \_x

`any`

###### Returns

`_x is any`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `null`

Defined in: [packages/core/src/candid/idl.ts:636](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L636)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:632](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L632)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:628](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L628)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`any`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ReservedClass`

Defined in: [packages/core/src/candid/idl.ts:616](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L616)

###### Parameters

###### instance

`any`

###### Returns

`instance is ReservedClass`

***

### ServiceClass

Defined in: [packages/core/src/candid/idl.ts:2009](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2009)

Represents an IDL type.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

#### Type Parameters

##### K

`K` *extends* `string` = `string`

##### Fields

`Fields` *extends* [`GenericIdlServiceFields`](#genericidlservicefields) = [`GenericIdlServiceFields`](#genericidlservicefields)

#### Constructors

##### Constructor

> **new ServiceClass**\<`K`, `Fields`\>(`fields`): [`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

Defined in: [packages/core/src/candid/idl.ts:2022](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2022)

###### Parameters

###### fields

`Fields`

###### Returns

[`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`K`, `Fields`\[`K`\]\][]

Defined in: [packages/core/src/candid/idl.ts:2021](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2021)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:2072](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2072)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:2013](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2013)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:2050](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2050)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:2034](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2034)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/core/src/candid/idl.ts:2037](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2037)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Principal`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/candid/idl.ts:2063](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2063)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

[`Principal`](../../../principal/api.md#principal)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:2044](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2044)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### fieldsAsObject()

> **fieldsAsObject**(): `Fields`

Defined in: [packages/core/src/candid/idl.ts:2081](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2081)

###### Returns

`Fields`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:2077](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2077)

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ServiceClass<string, GenericIdlServiceFields>`

Defined in: [packages/core/src/candid/idl.ts:2017](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2017)

###### Parameters

###### instance

`any`

###### Returns

`instance is ServiceClass<string, GenericIdlServiceFields>`

***

### TextClass

Defined in: [packages/core/src/candid/idl.ts:651](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L651)

Represents an IDL Text

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`string`\>

#### Constructors

##### Constructor

> **new TextClass**(): [`TextClass`](#textclass)

###### Returns

[`TextClass`](#textclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:689](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L689)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:652](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L652)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L375)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:660](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L660)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L368)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is string`

Defined in: [packages/core/src/candid/idl.ts:664](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L664)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `string`

Defined in: [packages/core/src/candid/idl.ts:681](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L681)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:677](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L677)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:671](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L671)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`string`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:693](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L693)

###### Parameters

###### x

`string`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is TextClass`

Defined in: [packages/core/src/candid/idl.ts:656](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L656)

###### Parameters

###### instance

`any`

###### Returns

`instance is TextClass`

***

### TupleClass

Defined in: [packages/core/src/candid/idl.ts:1511](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1511)

Represents Tuple, a syntactic sugar for Record.

#### Param

#### Extends

- [`RecordClass`](#recordclass)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Constructors

##### Constructor

> **new TupleClass**\<`T`\>(`_components`): [`TupleClass`](#tupleclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1522](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1522)

###### Parameters

###### \_components

[`Type`](#abstract-type)\<`any`\>[]

###### Returns

[`TupleClass`](#tupleclass)\<`T`\>

###### Overrides

[`RecordClass`](#recordclass).[`constructor`](#constructor-15)

#### Properties

##### \_components

> `protected` `readonly` **\_components**: [`Type`](#abstract-type)\<`any`\>[]

Defined in: [packages/core/src/candid/idl.ts:1520](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1520)

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1353](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1353)

###### Inherited from

[`RecordClass`](#recordclass).[`_fields`](#_fields)

#### Accessors

##### fieldsAsObject

###### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1482](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1482)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

###### Inherited from

[`RecordClass`](#recordclass).[`fieldsAsObject`](#fieldsasobject)

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1490](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1490)

###### Returns

`string`

###### Inherited from

[`RecordClass`](#recordclass).[`name`](#name-15)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1512](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1512)

###### Returns

`IdlTypeName`

###### Overrides

[`RecordClass`](#recordclass).[`typeName`](#typename-14)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1405](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1405)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Inherited from

[`RecordClass`](#recordclass).[`_buildTypeTableImpl`](#_buildtypetableimpl-14)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1529](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1529)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`RecordClass`](#recordclass).[`accept`](#accept-14)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`RecordClass`](#recordclass).[`buildTypeTable`](#buildtypetable-14)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`RecordClass`](#recordclass).[`checkType`](#checktype-14)

##### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:1533](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1533)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Overrides

[`RecordClass`](#recordclass).[`covariant`](#covariant-14)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:1560](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1560)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Overrides

[`RecordClass`](#recordclass).[`decodeValue`](#decodevalue-14)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1590](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1590)

###### Returns

`string`

###### Overrides

[`RecordClass`](#recordclass).[`display`](#display-14)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`RecordClass`](#recordclass).[`encodeType`](#encodetype-14)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1555](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1555)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`any`[]

###### Returns

`Uint8Array`

###### Overrides

[`RecordClass`](#recordclass).[`encodeValue`](#encodevalue-14)

##### tryAsTuple()

> **tryAsTuple**(): [`Type`](#abstract-type)\<`any`\>[] \| `null`

Defined in: [packages/core/src/candid/idl.ts:1364](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1364)

###### Returns

[`Type`](#abstract-type)\<`any`\>[] \| `null`

###### Inherited from

[`RecordClass`](#recordclass).[`tryAsTuple`](#tryastuple)

##### valueToString()

> **valueToString**(`values`): `string`

Defined in: [packages/core/src/candid/idl.ts:1595](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1595)

###### Parameters

###### values

`any`[]

###### Returns

`string`

###### Overrides

[`RecordClass`](#recordclass).[`valueToString`](#valuetostring-14)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is TupleClass<T>`

Defined in: [packages/core/src/candid/idl.ts:1516](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1516)

###### Type Parameters

###### T

`T` *extends* `any`[]

###### Parameters

###### instance

`any`

###### Returns

`instance is TupleClass<T>`

###### Overrides

[`RecordClass`](#recordclass).[`[hasInstance]`](#hasinstance-12)

***

### `abstract` Type

Defined in: [packages/core/src/candid/idl.ts:320](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L320)

Represents an IDL type.

#### Extended by

- [`PrimitiveType`](#abstract-primitivetype)
- [`ConstructType`](#abstract-constructtype)
- [`UnknownClass`](#unknownclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new Type**\<`T`\>(): [`Type`](#abstract-type)\<`T`\>

###### Returns

[`Type`](#abstract-type)\<`T`\>

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:322](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L322)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:321](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L321)

#### Methods

##### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:364](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L364)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:323](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L323)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

##### checkType()

> `abstract` **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:360](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L360)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:345](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L345)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:362](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L362)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

##### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:358](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L358)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:352](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L352)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:330](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L330)

###### Parameters

###### x

`T`

###### Returns

`string`

***

### UnknownClass

Defined in: [packages/core/src/candid/idl.ts:448](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L448)

Represents an IDL Unknown, a placeholder type for deserialization only.
When decoding a value as Unknown, all fields will be retained but the names are only available in
hashed form.
A deserialized unknown will offer it's actual type by calling the `type()` function.
Unknown cannot be serialized and attempting to do so will throw an error.

#### Extends

- [`Type`](#abstract-type)

#### Constructors

##### Constructor

> **new UnknownClass**(): [`UnknownClass`](#unknownclass)

###### Returns

[`UnknownClass`](#unknownclass)

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:514](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L514)

###### Returns

`string`

###### Overrides

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:449](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L449)

###### Returns

`IdlTypeName`

###### Overrides

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> `protected` **\_buildTypeTableImpl**(): `void`

Defined in: [packages/core/src/candid/idl.ts:510](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L510)

###### Returns

`void`

###### Overrides

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:461](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L461)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`_t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:457](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L457)

###### Parameters

###### \_t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> **covariant**(`x`): `x is any`

Defined in: [packages/core/src/candid/idl.ts:465](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L465)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is any`

###### Overrides

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> **decodeValue**(`b`, `t`): `any`

Defined in: [packages/core/src/candid/idl.ts:481](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L481)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`any`

###### Overrides

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L326)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> **encodeType**(): `never`

Defined in: [packages/core/src/candid/idl.ts:477](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L477)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:469](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L469)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(): `never`

Defined in: [packages/core/src/candid/idl.ts:473](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L473)

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is UnknownClass`

Defined in: [packages/core/src/candid/idl.ts:453](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L453)

###### Parameters

###### instance

`any`

###### Returns

`instance is UnknownClass`

***

### VariantClass

Defined in: [packages/core/src/candid/idl.ts:1605](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1605)

Represents an IDL Variant

#### Param

mapping of function name to Type

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

#### Constructors

##### Constructor

> **new VariantClass**(`fields?`): [`VariantClass`](#variantclass)

Defined in: [packages/core/src/candid/idl.ts:1616](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1616)

###### Parameters

###### fields?

`Record`\<`string`, [`Type`](#abstract-type)\> = `{}`

###### Returns

[`VariantClass`](#variantclass)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1614](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1614)

#### Accessors

##### alternativesAsObject

###### Get Signature

> **get** **alternativesAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1722](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1722)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1696](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1696)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1606](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1606)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1660](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1660)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1621](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1621)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Record<string, any>`

Defined in: [packages/core/src/candid/idl.ts:1625](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1625)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Record<string, any>`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `object`

Defined in: [packages/core/src/candid/idl.ts:1672](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1672)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`object`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1701](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1701)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1646](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1646)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1708](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1708)

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is VariantClass`

Defined in: [packages/core/src/candid/idl.ts:1610](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1610)

###### Parameters

###### instance

`any`

###### Returns

`instance is VariantClass`

***

### VecClass

Defined in: [packages/core/src/candid/idl.ts:988](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L988)

Represents an IDL Array

Arrays of fixed-sized nat/int type (e.g. nat8), are encoded from and decoded to TypedArrays (e.g. Uint8Array).
Arrays of float or other non-primitive types are encoded/decoded as untyped array in Javascript.

#### Param

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`T`[]\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new VecClass**\<`T`\>(`_type`): [`VecClass`](#vecclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1005](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1005)

###### Parameters

###### \_type

[`Type`](#abstract-type)\<`T`\>

###### Returns

[`VecClass`](#vecclass)\<`T`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_type

> **\_type**: [`Type`](#abstract-type)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1005](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1005)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1182](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1182)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:989](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L989)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1098](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1098)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1012](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1012)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L335)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`[]\>

Defined in: [packages/core/src/candid/idl.ts:381](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L381)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`[]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is T[]`

Defined in: [packages/core/src/candid/idl.ts:1016](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1016)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T[]`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`[]

Defined in: [packages/core/src/candid/idl.ts:1106](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1106)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`[]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1186](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1186)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:393](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L393)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1045](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1045)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`[]

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1190](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1190)

###### Parameters

###### x

`T`[]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is VecClass<T>`

Defined in: [packages/core/src/candid/idl.ts:993](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L993)

###### Type Parameters

###### T

`T`

###### Parameters

###### instance

`any`

###### Returns

`instance is VecClass<T>`

***

### `abstract` Visitor

Defined in: [packages/core/src/candid/idl.ts:219](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L219)

#### Extended by

- [`Render`](../index.md#render-4)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Constructors

##### Constructor

> **new Visitor**\<`D`, `R`\>(): [`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### Returns

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

#### Methods

##### visitBool()

> **visitBool**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:229](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L229)

###### Parameters

###### t

[`BoolClass`](#boolclass)

###### data

`D`

###### Returns

`R`

##### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L263)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitEmpty()

> **visitEmpty**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:226](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L226)

###### Parameters

###### t

[`EmptyClass`](#emptyclass)

###### data

`D`

###### Returns

`R`

##### visitFixedInt()

> **visitFixedInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:253](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L253)

###### Parameters

###### t

[`FixedIntClass`](#fixedintclass)

###### data

`D`

###### Returns

`R`

##### visitFixedNat()

> **visitFixedNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:256](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L256)

###### Parameters

###### t

[`FixedNatClass`](#fixednatclass)

###### data

`D`

###### Returns

`R`

##### visitFloat()

> **visitFloat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:250](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L250)

###### Parameters

###### t

[`FloatClass`](#floatclass)

###### data

`D`

###### Returns

`R`

##### visitFunc()

> **visitFunc**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:285](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L285)

###### Parameters

###### t

[`FuncClass`](#funcclass)

###### data

`D`

###### Returns

`R`

##### visitInt()

> **visitInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:244](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L244)

###### Parameters

###### t

[`IntClass`](#intclass)

###### data

`D`

###### Returns

`R`

##### visitNat()

> **visitNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L247)

###### Parameters

###### t

[`NatClass`](#natclass)

###### data

`D`

###### Returns

`R`

##### visitNull()

> **visitNull**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:232](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L232)

###### Parameters

###### t

[`NullClass`](#nullclass)

###### data

`D`

###### Returns

`R`

##### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:241](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L241)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitOpt()

> **visitOpt**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:269](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L269)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`OptClass`](#optclass)\<`T`\>

###### \_ty

[`Type`](#abstract-type)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:223](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L223)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitPrincipal()

> **visitPrincipal**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:259](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L259)

###### Parameters

###### t

[`PrincipalClass`](#principalclass)

###### data

`D`

###### Returns

`R`

##### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:282](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L282)

###### Type Parameters

###### T

`T`

###### Parameters

###### \_t

[`RecClass`](#recclass)\<`T`\>

###### ty

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitRecord()

> **visitRecord**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:272](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L272)

###### Parameters

###### t

[`RecordClass`](#recordclass)

###### \_fields

\[`string`, [`Type`](#abstract-type)\<`any`\>\][]

###### data

`D`

###### Returns

`R`

##### visitReserved()

> **visitReserved**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:235](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L235)

###### Parameters

###### t

[`ReservedClass`](#reservedclass)

###### data

`D`

###### Returns

`R`

##### visitService()

> **visitService**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:288](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L288)

###### Parameters

###### t

[`ServiceClass`](#serviceclass)

###### data

`D`

###### Returns

`R`

##### visitText()

> **visitText**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L238)

###### Parameters

###### t

[`TextClass`](#textclass)

###### data

`D`

###### Returns

`R`

##### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:275](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L275)

###### Type Parameters

###### T

`T` *extends* `any`[]

###### Parameters

###### t

[`TupleClass`](#tupleclass)\<`T`\>

###### components

[`Type`](#abstract-type)\<`any`\>[]

###### data

`D`

###### Returns

`R`

##### visitType()

> **visitType**\<`T`\>(`_t`, `_data`): `R`

Defined in: [packages/core/src/candid/idl.ts:220](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L220)

###### Type Parameters

###### T

`T`

###### Parameters

###### \_t

[`Type`](#abstract-type)\<`T`\>

###### \_data

`D`

###### Returns

`R`

##### visitVariant()

> **visitVariant**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:279](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L279)

###### Parameters

###### t

[`VariantClass`](#variantclass)

###### \_fields

\[`string`, [`Type`](#abstract-type)\<`any`\>\][]

###### data

`D`

###### Returns

`R`

##### visitVec()

> **visitVec**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:266](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L266)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`VecClass`](#vecclass)\<`T`\>

###### \_ty

[`Type`](#abstract-type)\<`T`\>

###### data

`D`

###### Returns

`R`

## Type Aliases

### GenericIdlFuncArgs

> **GenericIdlFuncArgs** = \[[`Type`](#abstract-type), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1870](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1870)

The generic type of the arguments of an [IDL Function](#func).

***

### GenericIdlFuncRets

> **GenericIdlFuncRets** = \[[`Type`](#abstract-type), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1875](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L1875)

The generic type of the return values of an [IDL Function](#func).

***

### GenericIdlServiceFields

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](#funcclass)\>

Defined in: [packages/core/src/candid/idl.ts:2007](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2007)

The generic type of the fields of an [IDL Service](#service).

***

### InterfaceFactory

> **InterfaceFactory** = (`idl`) => [`ServiceClass`](#serviceclass)

Defined in: [packages/core/src/candid/idl.ts:2410](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2410)

An Interface Factory, normally provided by a Candid code generation.

#### Parameters

##### idl

###### IDL

\{ `Bool`: [`BoolClass`](#boolclass); `Empty`: [`EmptyClass`](#emptyclass); `Float32`: [`FloatClass`](#floatclass); `Float64`: [`FloatClass`](#floatclass); `Func`: *typeof* [`Func`](#func); `Int`: [`IntClass`](#intclass); `Int16`: [`FixedIntClass`](#fixedintclass); `Int32`: [`FixedIntClass`](#fixedintclass); `Int64`: [`FixedIntClass`](#fixedintclass); `Int8`: [`FixedIntClass`](#fixedintclass); `Nat`: [`NatClass`](#natclass); `Nat16`: [`FixedNatClass`](#fixednatclass); `Nat32`: [`FixedNatClass`](#fixednatclass); `Nat64`: [`FixedNatClass`](#fixednatclass); `Nat8`: [`FixedNatClass`](#fixednatclass); `Null`: [`NullClass`](#nullclass); `Opt`: *typeof* [`Opt`](#opt); `Principal`: [`PrincipalClass`](#principalclass); `Rec`: *typeof* [`Rec`](#rec); `Record`: *typeof* [`Record`](#record); `Reserved`: [`ReservedClass`](#reservedclass); `Text`: [`TextClass`](#textclass); `Tuple`: *typeof* [`Tuple`](#tuple); `Unknown`: [`UnknownClass`](#unknownclass); `Variant`: *typeof* [`Variant`](#variant); `Vec`: *typeof* [`Vec`](#vec); `Service`: [`ServiceClass`](#serviceclass); \}

###### IDL.Bool

[`BoolClass`](#boolclass)

###### IDL.Empty

[`EmptyClass`](#emptyclass)

###### IDL.Float32

[`FloatClass`](#floatclass)

###### IDL.Float64

[`FloatClass`](#floatclass)

###### IDL.Func

*typeof* [`Func`](#func)

###### IDL.Int

[`IntClass`](#intclass)

###### IDL.Int16

[`FixedIntClass`](#fixedintclass)

###### IDL.Int32

[`FixedIntClass`](#fixedintclass)

###### IDL.Int64

[`FixedIntClass`](#fixedintclass)

###### IDL.Int8

[`FixedIntClass`](#fixedintclass)

###### IDL.Nat

[`NatClass`](#natclass)

###### IDL.Nat16

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat32

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat64

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat8

[`FixedNatClass`](#fixednatclass)

###### IDL.Null

[`NullClass`](#nullclass)

###### IDL.Opt

*typeof* [`Opt`](#opt)

###### IDL.Principal

[`PrincipalClass`](#principalclass)

###### IDL.Rec

*typeof* [`Rec`](#rec)

###### IDL.Record

*typeof* [`Record`](#record)

###### IDL.Reserved

[`ReservedClass`](#reservedclass)

###### IDL.Text

[`TextClass`](#textclass)

###### IDL.Tuple

*typeof* [`Tuple`](#tuple)

###### IDL.Unknown

[`UnknownClass`](#unknownclass)

###### IDL.Variant

*typeof* [`Variant`](#variant)

###### IDL.Vec

*typeof* [`Vec`](#vec)

###### IDL.Service

#### Returns

[`ServiceClass`](#serviceclass)

## Variables

### Bool

> `const` **Bool**: [`BoolClass`](#boolclass)

Defined in: [packages/core/src/candid/idl.ts:2455](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2455)

***

### Empty

> `const` **Empty**: [`EmptyClass`](#emptyclass)

Defined in: [packages/core/src/candid/idl.ts:2449](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2449)

***

### Float32

> `const` **Float32**: [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:2461](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2461)

***

### Float64

> `const` **Float64**: [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:2462](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2462)

***

### Int

> `const` **Int**: [`IntClass`](#intclass)

Defined in: [packages/core/src/candid/idl.ts:2458](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2458)

***

### Int16

> `const` **Int16**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2465](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2465)

***

### Int32

> `const` **Int32**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2466](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2466)

***

### Int64

> `const` **Int64**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2467](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2467)

***

### Int8

> `const` **Int8**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2464](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2464)

***

### Nat

> `const` **Nat**: [`NatClass`](#natclass)

Defined in: [packages/core/src/candid/idl.ts:2459](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2459)

***

### Nat16

> `const` **Nat16**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2470](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2470)

***

### Nat32

> `const` **Nat32**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2471](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2471)

***

### Nat64

> `const` **Nat64**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2472](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2472)

***

### Nat8

> `const` **Nat8**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2469](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2469)

***

### Null

> `const` **Null**: [`NullClass`](#nullclass)

Defined in: [packages/core/src/candid/idl.ts:2456](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2456)

***

### Principal

> `const` **Principal**: [`PrincipalClass`](#principalclass)

Defined in: [packages/core/src/candid/idl.ts:2474](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2474)

***

### Reserved

> `const` **Reserved**: [`ReservedClass`](#reservedclass)

Defined in: [packages/core/src/candid/idl.ts:2450](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2450)

***

### Text

> `const` **Text**: [`TextClass`](#textclass)

Defined in: [packages/core/src/candid/idl.ts:2457](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2457)

***

### Unknown

> `const` **Unknown**: [`UnknownClass`](#unknownclass)

Defined in: [packages/core/src/candid/idl.ts:2454](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2454)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.

## Functions

### decode()

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../index.md#jsonvalue)[]

Defined in: [packages/core/src/candid/idl.ts:2144](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2144)

Decode a binary value

#### Parameters

##### retTypes

[`Type`](#abstract-type)\<`any`\>[]

Types expected in the buffer.

##### bytes

`Uint8Array`

hex-encoded string, or buffer.

#### Returns

[`JsonValue`](../index.md#jsonvalue)[]

Value deserialised to JS type

***

### encode()

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:2111](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2111)

Encode a array of values

#### Parameters

##### argTypes

[`Type`](#abstract-type)\<`any`\>[]

array of Types

##### args

`any`[]

array of values

#### Returns

`Uint8Array`

serialised value

***

### Func()

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations?`): [`FuncClass`](#funcclass)\<`Args`, `Ret`\>

Defined in: [packages/core/src/candid/idl.ts:2532](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2532)

#### Type Parameters

##### Args

`Args` *extends* [`GenericIdlFuncArgs`](#genericidlfuncargs) = [`GenericIdlFuncArgs`](#genericidlfuncargs)

##### Ret

`Ret` *extends* [`GenericIdlFuncRets`](#genericidlfuncrets) = [`GenericIdlFuncRets`](#genericidlfuncrets)

#### Parameters

##### args

`Args`

array of IDL Types

##### ret

`Ret`

array of IDL Types

##### annotations?

`string`[] = `[]`

array of strings, [] by default

#### Returns

[`FuncClass`](#funcclass)\<`Args`, `Ret`\>

new FuncClass

***

### Opt()

> **Opt**\<`T`\>(`t`): [`OptClass`](#optclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2497](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2497)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](#abstract-type)\<`T`\>

IDL Type

#### Returns

[`OptClass`](#optclass)\<`T`\>

OptClass of Type

***

### Rec()

> **Rec**(): [`RecClass`](#recclass)

Defined in: [packages/core/src/candid/idl.ts:2521](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2521)

#### Returns

[`RecClass`](#recclass)

new RecClass

***

### Record()

> **Record**(`t`): [`RecordClass`](#recordclass)

Defined in: [packages/core/src/candid/idl.ts:2505](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2505)

#### Parameters

##### t

`Record`\<`string`, [`Type`](#abstract-type)\>

Record of string and IDL Type

#### Returns

[`RecordClass`](#recordclass)

RecordClass of string and Type

***

### resetSubtypeCache()

> **resetSubtypeCache**(): `void`

Defined in: [packages/core/src/candid/idl.ts:2611](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2611)

Resets the global subtyping cache

#### Returns

`void`

***

### Service()

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

Defined in: [packages/core/src/candid/idl.ts:2544](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2544)

#### Type Parameters

##### K

`K` *extends* `string` = `string`

##### Fields

`Fields` *extends* [`GenericIdlServiceFields`](#genericidlservicefields) = [`GenericIdlServiceFields`](#genericidlservicefields)

#### Parameters

##### t

`Fields`

Record of string and FuncClass

#### Returns

[`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

ServiceClass

***

### subtype()

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/core/src/candid/idl.ts:2638](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2638)

Subtyping on Candid types t1 <: t2 (Exported for testing)

#### Parameters

##### t1

[`Type`](#abstract-type)

The potential subtype

##### t2

[`Type`](#abstract-type)

The potential supertype

#### Returns

`boolean`

***

### Tuple()

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](#tupleclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2481](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2481)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### types

...`T`

array of any types

#### Returns

[`TupleClass`](#tupleclass)\<`T`\>

TupleClass from those types

***

### Variant()

> **Variant**(`fields`): [`VariantClass`](#variantclass)

Defined in: [packages/core/src/candid/idl.ts:2514](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2514)

#### Parameters

##### fields

`Record`\<`string`, [`Type`](#abstract-type)\>

Record of string and IDL Type

#### Returns

[`VariantClass`](#variantclass)

VariantClass

***

### Vec()

> **Vec**\<`T`\>(`t`): [`VecClass`](#vecclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2489](https://github.com/dfinity/icp-js-core/blob/916b9faddf956eb38be459f7d8506b25de329ffe/packages/core/src/candid/idl.ts#L2489)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](#abstract-type)\<`T`\>

IDL Type

#### Returns

[`VecClass`](#vecclass)\<`T`\>

VecClass from that type
